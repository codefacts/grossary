$(document).ready(function () {
    site.hash
        .on("/:categorySku", function (hs, params) {
        })
        .on("/", function (hs, params) {
        })
        .execute()
    ;
});