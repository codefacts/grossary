site.reactjs.Dashboard = React.createClass({
    getDefaultProps: function () {
        return {
            onInit: function () {
            },
            dataCountByDateUrl: "/contacts/countByDate",
            contactsSummaryUrl: "/contacts/summary",
        }
    },
    getInitialState: function () {
        var $this = this;
        return {};
    },
    componentDidMount: function () {
        var $this = this;
        $this.props.onInit($this);

    },
    render: function () {
        var $this = this;

        var char = {
            data: [{
                y: '2006',
                a: 100,
                b: 90
            }, {
                y: '2007',
                a: 75,
                b: 65
            }, {
                y: '2008',
                a: 50,
                b: 40
            }, {
                y: '2009',
                a: 75,
                b: 65
            }, {
                y: '2010',
                a: 50,
                b: 40
            }, {
                y: '2011',
                a: 75,
                b: 65
            }, {
                y: '2012',
                a: 100,
                b: 90
            }],
            xkey: 'y',
            ykeys: ['a', 'b'],
            labels: ['Series A', 'Series B'],
            hideHover: 'auto',
            resize: true
        }

        return (

            <div className="row">
                <div className="col-lg-6 col-md-6">
                    <div className="panel panel-primary">
                        <div className="panel-heading">
                            <div className="row">
                                <div className="col-xs-3">
                                    <i className="fa fa-comments fa-5x"></i>
                                </div>
                                <div className="col-xs-9 text-right">
                                    <div className="huge">26</div>
                                    <div>Total Data</div>
                                </div>
                            </div>
                        </div>
                        <a href="#">
                            <div className="panel-footer">
                                <span className="pull-left">View Details</span>
                                <span className="pull-right"><i className="fa fa-arrow-circle-right"></i></span>

                                <div className="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
                <div className="col-lg-6 col-md-6">
                    <div className="panel panel-green">
                        <div className="panel-heading">
                            <div className="row">
                                <div className="col-xs-3">
                                    <i className="fa fa-tasks fa-5x"></i>
                                </div>
                                <div className="col-xs-9 text-right">
                                    <div className="huge">12</div>
                                    <div>Today</div>
                                </div>
                            </div>
                        </div>
                        <a href="#">
                            <div className="panel-footer">
                                <span className="pull-left">View Details</span>
                                <span className="pull-right"><i className="fa fa-arrow-circle-right"></i></span>

                                <div className="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>


                <div className="col-md-12">
                    <div className="panel panel-default">
                        <div className="panel-heading">
                            Bar Chart Example
                        </div>
                        <div className="panel-body">
                            <site.reactjs.MorrisBar id="morris-bar-chart" style={{height: '450px'}} barConfig={char}/>
                        </div>
                    </div>
                </div>


            </div>

        );
    },
    updateData: function (params) {
        console.log("updated")
        console.log(params)
    },

    getDataCountByDate: function () {
        var $this = this;
        $.ajax({
            url: $this.props.dataCountByDateUrl,
            cache: false,
            success: function (data) {

            },
            error: function () {

            }
        })
    },
    getContactsSummary: function () {
    },
});